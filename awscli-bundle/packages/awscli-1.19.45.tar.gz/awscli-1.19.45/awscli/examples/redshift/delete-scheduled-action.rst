**To delete scheduled action**

The following ``delete-scheduled-action`` example deletes the specified scheduled action. ::

    aws redshift delete-scheduled-action \
        --scheduled-action-name myscheduledaction

This command does not produce any output.
